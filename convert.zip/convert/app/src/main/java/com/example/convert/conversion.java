package com.example.convert;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
public class conversion extends AppCompatActivity {
    EditText g, kg, usd, nrs;
    Button cw, cc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conversion);

        g=(EditText) findViewById(R.id.g);
        kg=(EditText) findViewById(R.id.kg);
        usd=(EditText) findViewById(R.id.usd);
        nrs=(EditText) findViewById(R.id.nrs);

        cw=(Button) findViewById(R.id.cw);
        cc=(Button) findViewById(R.id.cc);
        cw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Float a = Float.parseFloat(g.getText().toString());
                Float b = a/1000;
                kg.setText(Float.toString(b));
            }
        });
        cc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Float c = Float.parseFloat(nrs.getText().toString());
                Float d = c/100;
                usd.setText(Float.toString(d));
            }
        });
    }
}